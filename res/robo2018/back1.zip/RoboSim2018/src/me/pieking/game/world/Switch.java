package me.pieking.game.world;

import java.awt.Color;
import java.awt.Graphics2D;

public class Switch {

	protected ScalePlatform red;
	protected ScalePlatform blue;
	protected TEAM ownership = TEAM.NONE;
	
	public Switch(double x, double y) {
		red = new ScalePlatform(x, y - 3.5);
		blue = new ScalePlatform(x, y + 3.5);
	}
	
	public void render(Graphics2D g) {
		red.render(g);
		blue.render(g);
	}

	public void tick() {
		if(red.numCubes() == blue.numCubes()) {
			ownership = TEAM.NONE;
		}else if(red.numCubes() > blue.numCubes()) {
			ownership = TEAM.RED;
		}else {
			ownership = TEAM.BLUE;
		}
		
		red.base.color = Color.GRAY;
		blue.base.color = Color.GRAY;
		
		if(ownership == TEAM.RED) red.base.color = Color.RED;
		if(ownership == TEAM.BLUE) blue.base.color = Color.BLUE;
	}

	public ScalePlatform getRedPlatform() {
		return red;
	}
	
	public ScalePlatform getBluePlatform() {
		return blue;
	}
	
	public TEAM getOwner() {
		return ownership;
	}
	
	public static enum TEAM {
		NONE,
		BLUE,
		RED;
	}
	
}
