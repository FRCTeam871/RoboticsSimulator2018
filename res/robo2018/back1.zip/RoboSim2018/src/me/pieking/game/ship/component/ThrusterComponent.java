package me.pieking.game.ship.component;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Point2D;

import org.dyn4j.dynamics.BodyFixture;
import org.dyn4j.geometry.Circle;
import org.dyn4j.geometry.Mass;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Polygon;
import org.dyn4j.geometry.Vector2;

import me.pieking.game.Game;
import me.pieking.game.Rand;
import me.pieking.game.Utils;
import me.pieking.game.gfx.AnimatedImage;
import me.pieking.game.gfx.Sprite;
import me.pieking.game.gfx.Spritesheet;
import me.pieking.game.sound.Sound;
import me.pieking.game.sound.SoundClip;
import me.pieking.game.world.GameObject;
import me.pieking.game.world.GameObjectFilter;
import me.pieking.game.world.GameObjectFilter.FilterType;
import me.pieking.game.world.Player;
import me.pieking.game.world.PlayerFilter;

public class ThrusterComponent extends ActivatableComponent {

	public static Sprite sprOff = Spritesheet.tiles.subTile(0, 4);
	public static AnimatedImage sprOn;
	static {
		Point[] onPts = new Point[4];
		for(int i = 0; i < onPts.length; i++){
			onPts[i] = new Point(i + 1, 4);
		}
		sprOn = Spritesheet.tiles.animatedTile(onPts);
		sprOn.speed = 20f;
	}
	
	public SoundClip rocket;
	
	public float force = 6f;
	
	public ThrusterComponent(int x, int y, int rot) {
		super(x, y, 1, 1, rot, 100);
		sprite = sprOff;
		
		new Thread(() -> {
			rocket = Sound.loadSound("rocket.ogg");
		}).start();
	}
	
	@Override
	public GameObject createBody(Player player){
		
		GameObject base = new GameObject();
		base.setAutoSleepingEnabled(false);
		base.color = Color.GRAY;
		Polygon p = new Polygon(new Vector2(unitSize/4, 0), new Vector2(unitSize*0.75, 0), new Vector2(unitSize*0.9, unitSize/2), new Vector2(unitSize*0.75, unitSize), new Vector2(unitSize*0.25, unitSize), new Vector2(unitSize*0.1, unitSize/2));
		p.translate(-unitSize/2, -unitSize/2);
		BodyFixture bf = new BodyFixture(p);
		bf.setFilter(new PlayerFilter(player));
		base.addFixture(bf);
		base.setMass(new Mass(base.getMass().getCenter(), 0, 0));
		base.setMass(MassType.NORMAL);
		
		base.setAngularDamping(0);
		base.setLinearDamping(0);
		
		return base;
	}
	
	@Override
	public void tick(Player pl) {
		super.tick(pl);
		
		
		if(activated){
//			System.out.println("booooost");
			
			float speed = force;
			Point2D.Float pt = Utils.polarToCartesian((float) Math.toRadians(Math.toDegrees(lastBody.getTransform().getRotation()) + 90), speed);
			Vector2 vec = lastBody.getWorldCenter().subtract(lastBody.getWorldCenter().copy().add(pt.x, pt.y));
			lastBody.applyForce(vec);
			
			GameObject fire = new GameObject();
			BodyFixture fixture = new BodyFixture(new Circle(Rand.range(2.5f, 4f) / 45f));
			fire.addFixture(fixture);
			//fixture.setSensor(true);
			fixture.setFilter(new GameObjectFilter(FilterType.PARTICLE));
			fire.translate(lastBody.getWorldCenter());
			fire.setMass(MassType.NORMAL);
			Color c = new Color(255, Rand.range(70, 140), 0);
			float shade = Rand.range(0.6f, 0.9f);
			c = new Color(shade * 0.6f, shade, shade, 1f);
			//System.out.println(lastBody.getLinearVelocity().getMagnitude());
			
			fire.color = c;
			//System.out.println(lastBody.getLinearVelocity().getMagnitude());
			fire.applyForce(vec.copy().multiply(-3).setDirection(vec.copy().multiply(-5).getDirection() + Rand.range(-0.2f, 0.2f)).setMagnitude(3f).add(lastBody.getLinearVelocity()));
			fire.destructionTime = fire.creationTime + 1000;
			
			Game.getWorld().addParticle(fire);
			
		}
		
	}
	
	@Override
	public String getDisplayName() {
		return "Thruster";
	}
	
	@Override
	public void activate() {
		super.activate();
		
		rocket.loop();
		sprite = sprOn;
	}
	
	@Override
	public void deactivate() {
		super.deactivate();
		
		rocket.pause();
		sprite = sprOff;
	}

}
