package me.pieking.game.world;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import org.dyn4j.dynamics.Body;
import org.dyn4j.dynamics.BodyFixture;
import org.dyn4j.dynamics.World;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Polygon;
import org.dyn4j.geometry.Rectangle;
import org.dyn4j.geometry.Triangle;
import org.dyn4j.geometry.Vector2;

import me.pieking.game.Game;
import me.pieking.game.Rand;
import me.pieking.game.gfx.Fonts;
import me.pieking.game.gfx.Images;
import me.pieking.game.gfx.Sprite;
import me.pieking.game.ship.Ship;
import me.pieking.game.ship.component.Component;

public class GameWorld {
	public static final double ANGULAR_DAMPING = 50;
	public static final double LINEAR_DAMPING = 16;

	public static boolean shipAligned = false;
	
	public static Sprite field = Images.getSprite("field_temp.png");

	public World world;
	
	public double xOffset = 0;
	public double yOffset = 0;
	
	public List<GameObject> toRemove = new ArrayList<GameObject>();
	public List<GameObject> walls = new ArrayList<GameObject>();
	public List<GameObject> particles = new ArrayList<GameObject>();
	public List<PowerCube> cubes = new ArrayList<PowerCube>();
	public List<ScalePlatform> scalePlatforms = new ArrayList<ScalePlatform>();
	public List<Switch> scales = new ArrayList<Switch>();
	
	public Player selfPlayer;
	public List<Player> players = new ArrayList<Player>();
	
	public GameWorld(){
		initializeWorld();
		world.addListener(new GameListener());
	}
	
	public int score = 0;

	private GameObject floor;
	private GameObject floor2;
	private GameObject floor3;
	private GameObject floor4;
	
	public static float FIELD_SCALE = 1f;
	double fieldXofs = 28.1;
	double fieldYofs = 11;
	
	public static Vector2 mouseWorldPos = new Vector2();
	
	public void initializeWorld() {
		// create the world
		this.world = new World();
		// create all your bodies/joints
		world.setGravity(new Vector2(0, 0));
		//world.setGravity(new Vector2(0, 0));
		
//		for(int i = 0; i < 20; i++){
//			Planet p;
//			
//			int size = 2;
//			if(i == 0){
//				p = new Planet(200 * size, world, 0, 130, Atmosphere.OXYGEN);
//			}else{
//				
//				p = new Planet(Rand.range(50 * size, 300 * size), world, ((i % 5) * 2000 * size) + Rand.range(-500 * size, 500 * size), ((i / 5) * 2000 * size) + Rand.range(-500 * size, 500 * size));
//				p.atm = Atmosphere.values()[Rand.range(0, Atmosphere.values().length-1)];
//			}
//
//			if(i == 0){
//				homePlanet = p;
//			}
//			planets.add(p);
//		}
		//planets.add(new Planet(100, world, 400, 400));
		//planets.add(new Planet(300, world, -600, -700));
		
		// create the floor
		
		floor = new GameObject();
		floor.color = new Color(0f, 0.5f, 0f, 1f);
		double w = (field.getWidth() * GameObject.SCALE * 0.05) / GameObject.SCALE * FIELD_SCALE;
		double h = (field.getHeight() * GameObject.SCALE * 0.05) / GameObject.SCALE * FIELD_SCALE;
		Rectangle floorRect = new Rectangle(w, 40 / GameObject.SCALE * FIELD_SCALE);
		floorRect.translate(w/2, Component.unitSize * 2 * FIELD_SCALE);
		BodyFixture f1 = new BodyFixture(floorRect);
		f1.setDensity(0.5f);
		floor.addFixture(f1);
		
		world.addBody(floor);
		
		floor2 = new GameObject();
		floor2.color = new Color(0f, 0.5f, 0f, 1f);
		Rectangle floor2Rect = new Rectangle(w, 40 / GameObject.SCALE * FIELD_SCALE);
		floor2Rect.translate(w/2, h - Component.unitSize * 2 * FIELD_SCALE);
		BodyFixture f2 = new BodyFixture(floor2Rect);
		f2.setDensity(0.5f);
		floor2.addFixture(f2);
		
		world.addBody(floor2);
		
		floor3 = new GameObject();
		floor3.color = new Color(0f, 0.5f, 0f, 1f);
		Rectangle floor3Rect = new Rectangle(40 / GameObject.SCALE * FIELD_SCALE, h);
		floor3Rect.translate(Component.unitSize * 16 * FIELD_SCALE, h/2);
		BodyFixture f3 = new BodyFixture(floor3Rect);
		f3.setDensity(0.5f);
		floor3.addFixture(f3);
		
		world.addBody(floor3);
		
		GameObject slopeUL = new GameObject();
		Triangle t1 = new Triangle(new Vector2(-1 * FIELD_SCALE, -1 * FIELD_SCALE), new Vector2(3 * FIELD_SCALE, -1 * FIELD_SCALE), new Vector2(-1 * FIELD_SCALE, 2 * FIELD_SCALE));
		t1.translate(Component.unitSize * 16 * FIELD_SCALE + (40 / GameObject.SCALE * FIELD_SCALE), 40 / GameObject.SCALE * FIELD_SCALE + (Component.unitSize * 2 * FIELD_SCALE));
		BodyFixture tbf1 = new BodyFixture(t1);
		slopeUL.addFixture(tbf1);
		world.addBody(slopeUL);
		walls.add(slopeUL);
		
		GameObject slopeBL = new GameObject();
		Triangle t2 = new Triangle(new Vector2(-1 * FIELD_SCALE, -1 * FIELD_SCALE), new Vector2(-1 * FIELD_SCALE, -4 * FIELD_SCALE), new Vector2(3 * FIELD_SCALE, -1 * FIELD_SCALE));
		t2.translate((Component.unitSize * 16 * FIELD_SCALE + (40 / GameObject.SCALE * FIELD_SCALE)), h - (40 / GameObject.SCALE * FIELD_SCALE + (Component.unitSize * 2 * FIELD_SCALE)) + (2 * FIELD_SCALE));
		BodyFixture tbf2 = new BodyFixture(t2);
		slopeBL.addFixture(tbf2);
		world.addBody(slopeBL);
		walls.add(slopeBL);
		
		floor4 = new GameObject();
		floor4.color = new Color(0f, 0.5f, 0f, 1f);
		Rectangle floor4Rect = new Rectangle(40 / GameObject.SCALE * FIELD_SCALE, h);
		floor4Rect.translate(w - Component.unitSize * 16.5 * FIELD_SCALE, h/2);
		BodyFixture f4 = new BodyFixture(floor4Rect);
		f4.setDensity(0.5f);
		floor4.addFixture(f4);

		world.addBody(floor4);
		
		walls.add(floor);
		walls.add(floor2);
		walls.add(floor3);
		walls.add(floor4);
		
		
		addPowerCube(new PowerCube(0 + fieldXofs, 0 + fieldYofs, 0));
		
		addPowerCube(new PowerCube(5 + fieldXofs, 0 + fieldYofs, 0));
		addPowerCube(new PowerCube(5 + fieldXofs, 1 + fieldYofs, 0));
		addPowerCube(new PowerCube(5 + fieldXofs, 2 + fieldYofs, 0));
		addPowerCube(new PowerCube(5 + fieldXofs, -1 + fieldYofs, 0));
		addPowerCube(new PowerCube(5 + fieldXofs, -2 + fieldYofs, 0));
		
		addPowerCube(new PowerCube(-5 + fieldXofs, 0 + fieldYofs, 0));
		addPowerCube(new PowerCube(-5 + fieldXofs, 1 + fieldYofs, 0));
		addPowerCube(new PowerCube(-5 + fieldXofs, 2 + fieldYofs, 0));
		addPowerCube(new PowerCube(-5 + fieldXofs, -1 + fieldYofs, 0));
		addPowerCube(new PowerCube(-5 + fieldXofs, -2 + fieldYofs, 0));
		
		addPowerCube(new PowerCube(-13 + fieldXofs, 0.8 + fieldYofs, 0));
		addPowerCube(new PowerCube(-13 + PowerCube.SIZE + fieldXofs, 0.8 - PowerCube.SIZE/2 + fieldYofs, 0));
		addPowerCube(new PowerCube(-13 + PowerCube.SIZE + fieldXofs, 0.8 + PowerCube.SIZE/2 + fieldYofs, 0));
		
//		addPowerCube(new PowerCube(1 + fieldXofs, -2 + fieldYofs, 0));
		
		
		addScale(new Switch(10.15 + fieldXofs, 0 + fieldYofs));
		addScale(new Scale(0.07 + fieldXofs, 0 + fieldYofs));
		addScale(new Switch(-10.15 + fieldXofs, 0 + fieldYofs));
		
		GameObject go = new GameObject();
		
		Rectangle r = new Rectangle(Component.unitSize * 2, Component.unitSize / 8);
		r.translate(Component.unitSize/2, Component.unitSize/2);
		BodyFixture bf = new BodyFixture(r);
		bf.setFilter(new PlayerFilter(selfPlayer));
		go.addFixture(bf);
		
		r = new Rectangle(Component.unitSize / 8, Component.unitSize * .75);
		r.translate(-Component.unitSize/2, Component.unitSize / 8);
		bf = new BodyFixture(r);
		bf.setFilter(new PlayerFilter(selfPlayer));
		go.addFixture(bf);
		
		r = new Rectangle(Component.unitSize / 8, Component.unitSize * .75);
		r.translate(Component.unitSize/2 + Component.unitSize, Component.unitSize / 8);
		bf = new BodyFixture(r);
		bf.setFilter(new PlayerFilter(selfPlayer));
		go.addFixture(bf);
		
		go.translate(19.5, 12);
		
		go.setMass(MassType.NORMAL);
		go.applyForce(new Vector2(0, -80));
		world.addBody(go);
//		particles.add(go);
		
//		GameObject floor2 = new GameObject();
//		floor2.color = Color.GRAY;
//		
//		Rectangle floorRect2 = new Rectangle(150 / GameObject.SCALE, 100 / GameObject.SCALE);
//		floorRect2.translate(75 / GameObject.SCALE, (Game.getHeight() - 50 - 40) / GameObject.SCALE);
//		BodyFixture f2 = new BodyFixture(floorRect2);
//		f2.setDensity(0.5f);
//		floor2.addFixture(f2);
//		
//		world.addBody(floor2);
//		
//		
//		GameObject floor3 = new GameObject();
//		floor3.color = Color.GRAY;
//		
//		Rectangle floorRect3 = new Rectangle(300 / GameObject.SCALE, 100 / GameObject.SCALE);
//		floorRect3.translate((Game.getWidth() - 150 + (150)) / GameObject.SCALE, (Game.getHeight() - 50 - 40) / GameObject.SCALE);
//		BodyFixture f3 = new BodyFixture(floorRect3);
//		f3.setDensity(0.5f);
//		floor3.addFixture(f3);
//		
//		world.addBody(floor3);
		
		
//		for(int i = 0; i < 6; i++){
//			GameObject block = new GameObject();
//			block.color = Color.DARK_GRAY;
//			
//			Rectangle blockRect = new Rectangle(30 / GameObject.SCALE, 30 / GameObject.SCALE);
//			blockRect.translate((660 + (5 * i)) / GameObject.SCALE, (Game.getHeight() - 50 - 40 - 200 - (5 * i)) / GameObject.SCALE);
//			BodyFixture fx = new BodyFixture(blockRect);
//			fx.setDensity(0.5f);
//			block.addFixture(fx);
//			block.setMass(MassType.NORMAL);
//			block.magnetable = true;
//			block.magneticLevel = 0.5f;
//			world.addBody(block);
//		}
		
//		Rectangle floorRect2 = new Rectangle(20 / GameObject.SCALE, 300 / GameObject.SCALE);
//		BodyFixture f2 = new BodyFixture(floorRect2);
//		f2.setDensity(0.5f);
//		floor.addFixture(f2);
//		floorRect2.translate(-250 / GameObject.SCALE, -150 / GameObject.SCALE);
//		
//		Rectangle floorRect3 = new Rectangle(20 / GameObject.SCALE, 300 / GameObject.SCALE);
//		BodyFixture f3 = new BodyFixture(floorRect3);
//		f3.setDensity(0.5f);
//		floor.addFixture(f3);
//		floorRect3.translate(250 / GameObject.SCALE, -150 / GameObject.SCALE);
//		
//		floor.setMass(MassType.INFINITE);
//		// move the floor down a bit
//		//floor.translate(0.0, -4.0);
//		floor.translate(300 / GameObject.SCALE, 400 / GameObject.SCALE);
//		this.world.addBody(floor);
//		
//		
//		GameObject water = new GameObject();
//		water.color = new Color(0.2f, 0.2f, 1f, 0.5f);
//		
//		Rectangle waterR = new Rectangle(500 / GameObject.SCALE, 200 / GameObject.SCALE);
//		BodyFixture fx = new BodyFixture(waterR);
//		fx.setSensor(true);
//		water.addFixture(fx);
//		//water.translate(0, -100 / GameObject.SCALE);
//		waterR.translate(300 / GameObject.SCALE, 300 / GameObject.SCALE);
//		waterR.translate(0, 0 / GameObject.SCALE);
//		water.setMass(MassType.INFINITE);
//		this.world.addBody(water);
//		this.water = water;
//		// create a triangle object
//		Triangle triShape = new Triangle(
//				new Vector2(0.0, 0.5), 
//				new Vector2(-0.5, -0.5), 
//				new Vector2(0.5, -0.5));
//		GameObject triangle = new GameObject();
//		triangle.addFixture(triShape);
//		triangle.setMass(MassType.NORMAL);
//		triangle.translate(-1.0, 2.0);
//		// test having a velocity
//		triangle.getLinearVelocity().set(5.0, 0.0);
//		this.world.addBody(triangle);
		
//		for(int i = 0; i < 0; i++){
//			GameObject r1 = new GameObject();
//			BodyFixture fixture = new BodyFixture(new Circle(2 / GameObject.SCALE));
//			fixture.setDensity(0.1f + (0.01f * i));
//			r1.addFixture(fixture);
//			fixture.setRestitution(0);
//			
//			r1.setMass(MassType.NORMAL);
//			r1.translate((100 + ((i%100) * 2)) / GameObject.SCALE, (300 - ((i/100)*10)) / GameObject.SCALE);
//			r1.color = Color.CYAN;
//			this.world.addBody(r1);
//		}
		
//		for(int i = 0; i < 0; i++){
//		//GameObject r1 = createRacecarFixture();
//			GameObject r1 = new GameObject();
//			r1.desiredRotation = 90f;
//			BodyFixture fixture = new BodyFixture(new Rectangle(Rand.range(10, 60) / GameObject.SCALE, Rand.range(10, 60) / GameObject.SCALE));
//			fixture.setDensity(0.5f);
//			r1.addFixture(fixture);
//			fixture.setRestitution(0.5d);
//			
//			r1.setMass(MassType.NORMAL);
//			r1.translate(400 / GameObject.SCALE, 300 / GameObject.SCALE);
//			//System.out.println(r1 + " " + r1.desiredRotation);
//			r1.desiredRotation = Rand.range(0f, 360f);
//			this.world.addBody(r1);
//		}
		
//		GameObject obj = createBoatObject();
//		obj.translate(300 / GameObject.SCALE, 100 / GameObject.SCALE);
//		world.addBody(obj);
		
		/*
		GameObject r2 = new GameObject();
		BodyFixture fixture2 = new BodyFixture(new Rectangle(200 / GameObject.SCALE, 50 / GameObject.SCALE));
		fixture2.setDensity(1f);
		r2.addFixture(fixture2);
		fixture2.setRestitution(0.5d);
		
		r2.setMass(MassType.NORMAL);
		r2.translate(200 / GameObject.SCALE, 300 / GameObject.SCALE);
		r2.desiredRotation = 10f;
		
		this.world.addBody(r2);*/
		
		//r1.applyForce(new Vector2(-100, 100));
		//r1.applyTorque(1d);
//		// create a circle
//		Circle cirShape = new Circle(0.5);
//		GameObject circle = new GameObject();
//		circle.addFixture(cirShape);
//		circle.setMass(MassType.NORMAL);
//		circle.translate(2.0, 2.0);
//		// test adding some force
//		circle.applyForce(new Vector2(-100.0, 0.0));
//		// set some linear damping to simulate rolling friction
//		circle.setLinearDamping(0.05);
//		this.world.addBody(circle);
//		
//		// try a rectangle
//		Rectangle rectShape = new Rectangle(1.0, 1.0);
//		GameObject rectangle = new GameObject();
//		rectangle.addFixture(rectShape);
//		rectangle.setMass(MassType.NORMAL);
//		rectangle.translate(0.0, 2.0);
//		rectangle.getLinearVelocity().set(-5.0, 0.0);
//		this.world.addBody(rectangle);
//		
//		// try a polygon with lots of vertices
//		Polygon polyShape = Geometry.createUnitCirclePolygon(10, 1.0);
//		GameObject polygon = new GameObject();
//		polygon.addFixture(polyShape);
//		polygon.setMass(MassType.NORMAL);
//		polygon.translate(-2.5, 2.0);
//		// set the angular velocity
//		polygon.setAngularVelocity(Math.toRadians(-20.0));
//		this.world.addBody(polygon);
//		
//		// try a compound object
//		Circle c1 = new Circle(0.5);
//		BodyFixture c1Fixture = new BodyFixture(c1);
//		c1Fixture.setDensity(0.5);
//		Circle c2 = new Circle(0.5);
//		BodyFixture c2Fixture = new BodyFixture(c2);
//		c2Fixture.setDensity(0.5);
//		Rectangle rm = new Rectangle(2.0, 1.0);
//		// translate the circles in local coordinates
//		c1.translate(-1.0, 0.0);
//		c2.translate(1.0, 0.0);
//		GameObject capsule = new GameObject();
//		capsule.addFixture(c1Fixture);
//		capsule.addFixture(c2Fixture);
//		capsule.addFixture(rm);
//		capsule.setMass(MassType.NORMAL);
//		capsule.translate(0.0, 4.0);
//		this.world.addBody(capsule);
//		
//		GameObject issTri = new GameObject();
//		issTri.addFixture(Geometry.createIsoscelesTriangle(1.0, 3.0));
//		issTri.setMass(MassType.NORMAL);
//		issTri.translate(2.0, 3.0);
//		this.world.addBody(issTri);
//		
//		GameObject equTri = new GameObject();
//		equTri.addFixture(Geometry.createEquilateralTriangle(2.0));
//		equTri.setMass(MassType.NORMAL);
//		equTri.translate(3.0, 3.0);
//		this.world.addBody(equTri);
//		
//		GameObject rightTri = new GameObject();
//		rightTri.addFixture(Geometry.createRightTriangle(2.0, 1.0));
//		rightTri.setMass(MassType.NORMAL);
//		rightTri.translate(4.0, 3.0);
//		this.world.addBody(rightTri);
//		
//		GameObject cap = new GameObject();
//		cap.addFixture(new Capsule(1.0, 0.5));
//		cap.setMass(MassType.NORMAL);
//		cap.translate(-3.0, 3.0);
//		this.world.addBody(cap);
//		
//		GameObject slice = new GameObject();
//		slice.addFixture(new Slice(0.5, Math.toRadians(120)));
//		slice.setMass(MassType.NORMAL);
//		slice.translate(-3.0, 3.0);
//		this.world.addBody(slice);
}
	
	public void addPlayer(Player pl) {
		players.add(pl);
		world.addBody(pl.base);
	}

	public void render(Graphics2D g){
		
		//System.out.println("r3");
		AffineTransform ot = g.getTransform();
		
		AffineTransform yFlip = AffineTransform.getScaleInstance(1, 1);
		AffineTransform move = AffineTransform.getTranslateInstance(0, 0);
		g.transform(yFlip);
		g.transform(move);
		
		if(shipAligned) g.rotate(-getSelf().base.getTransform().getRotation(), Game.getWidth()/2, Game.getHeight()/2);
		AffineTransform ofs = AffineTransform.getTranslateInstance(xOffset, yOffset);
		g.transform(ofs);

		
		List<Body> bodies = new ArrayList<Body>();
		bodies.addAll(world.getBodies());
		
		for(Body b : bodies){
			GameObject o = (GameObject) b;
			
//			if(Game.game.input.leftMouse && o.pullable){
//				if(o.getMass().getType() == MassType.NORMAL){
//					Point frameloc = Game.game.frame.getLocation();
//					frameloc.x += Game.game.frame.getInsets().right;
//					frameloc.y += Game.game.frame.getInsets().top;
//					float width = 20 - ((float) new Point((int)(o.getWorldCenter().x * GameObject.SCALE), (int)(o.getWorldCenter().y * GameObject.SCALE)).distance(new Point2D.Float(MouseInfo.getPointerInfo().getLocation().x - frameloc.x, MouseInfo.getPointerInfo().getLocation().y - frameloc.y)) / 10f);
//					
//					if(width < 1) width = 1;
//					
//					g.setColor(o.color.darker());
//					g.setStroke(new BasicStroke(width));
//					g.drawLine((int)(o.getWorldCenter().x * GameObject.SCALE), (int)(o.getWorldCenter().y * GameObject.SCALE), (int)(MouseInfo.getPointerInfo().getLocation().x - frameloc.x - xOffset), (int) (MouseInfo.getPointerInfo().getLocation().y - frameloc.y - yOffset));
//					g.setStroke(new BasicStroke(1f));
//				}
//			}
//			o.render(g);
			
		}
		
		g.drawImage(field.getImage(), 0, 0, (int)(field.getWidth() * GameObject.SCALE * 0.05 * FIELD_SCALE), (int)(field.getHeight() * GameObject.SCALE * 0.05 * FIELD_SCALE), null);
		
		List<GameObject> wal = new ArrayList<GameObject>();
		wal.addAll(walls);
		for(GameObject o : wal){
			o.render(g);
		}
		
		List<GameObject> par = new ArrayList<GameObject>();
		par.addAll(particles);
		for(GameObject o : par){
			o.render(g);
		}
		
		List<Switch> sca = new ArrayList<Switch>();
		sca.addAll(scales);
//		System.out.println(scales + " " + sca);
		for(Switch o : sca){
			if(o != null) o.render(g);
		}
		
		List<PowerCube> cub = new ArrayList<PowerCube>();
		cub.addAll(cubes);
		for(PowerCube o : cub){
			if(o != null) o.render(g);
		}
		
		List<Player> pl = new ArrayList<Player>();
		pl.addAll(players);
		for(Player p : pl){
			if(p != null) p.render(g);
		}
		
//		if(Game.game.input.rightMouse){
//			Point frameloc = Game.game.frame.getLocation();
//			frameloc.x += Game.game.frame.getInsets().right;
//			frameloc.y += Game.game.frame.getInsets().top;
//			g.drawLine(Game.game.input.rStart.x - frameloc.x, Game.game.input.rStart.y - frameloc.y, MouseInfo.getPointerInfo().getLocation().x - frameloc.x, MouseInfo.getPointerInfo().getLocation().y - frameloc.y);
//		}
		
		g.setColor(Color.GREEN);
		g.drawRect(0, 0, 10, 10);
		
		g.setTransform(ot);
		
		renderHUD(g);
	}
	
	public void render(Graphics2D g, double xOffset2, double yOffset2, double scale){
		
		double realScale = GameObject.SCALE;
		GameObject.SCALE = scale;
		
		//System.out.println("r3");
		AffineTransform ot = g.getTransform();
		
		AffineTransform yFlip = AffineTransform.getScaleInstance(1, 1);
		AffineTransform move = AffineTransform.getTranslateInstance(0, 0);
		g.transform(yFlip);
		g.transform(move);
		
		AffineTransform ofs = AffineTransform.getTranslateInstance(xOffset2, yOffset2);
		g.transform(ofs);
		
		List<Body> bodies = new ArrayList<Body>();
		bodies.addAll(world.getBodies());
		
		floor.render(g);
		
		List<GameObject> par = new ArrayList<GameObject>();
		par.addAll(particles);
		for(GameObject o : par){
			o.render(g);
		}
		
		List<PowerCube> cub = new ArrayList<PowerCube>();
		cub.addAll(cubes);
		for(PowerCube o : cub){
			if(o != null) o.base.render(g);
		}
		
		List<Switch> sca = new ArrayList<Switch>();
		sca.addAll(scales);
//		System.out.println(scales + " " + sca);
		for(Switch o : sca){
			if(o != null) o.render(g);
		}
		
		List<Player> pl = new ArrayList<Player>();
		pl.addAll(players);
		for(Player p : pl){
			if(p != null) p.ship.render(g);
		}
		
//		if(Game.game.input.rightMouse){
//			Point frameloc = Game.game.frame.getLocation();
//			frameloc.x += Game.game.frame.getInsets().right;
//			frameloc.y += Game.game.frame.getInsets().top;
//			g.drawLine(Game.game.input.rStart.x - frameloc.x, Game.game.input.rStart.y - frameloc.y, MouseInfo.getPointerInfo().getLocation().x - frameloc.x, MouseInfo.getPointerInfo().getLocation().y - frameloc.y);
//		}
		
//		g.setColor(Color.GREEN);
//		g.drawRect(0, 0, 10, 10);
		
		g.setTransform(ot);
		
//		renderHUD(g);
		
		GameObject.SCALE = realScale;
	}
	
	public AffineTransform getTransform(){
		
		AffineTransform trans = new AffineTransform();
		
		AffineTransform yFlip = AffineTransform.getScaleInstance(1, 1);
		AffineTransform move = AffineTransform.getTranslateInstance(0, 0);
		trans.concatenate(yFlip);
		trans.concatenate(move);
		
		AffineTransform ofs = AffineTransform.getTranslateInstance(xOffset, yOffset);
		trans.concatenate(ofs);
		
		return trans;
	}
	
	private void renderHUD(Graphics2D g) {
		
		if(Ship.buildMode){
			g.setFont(Fonts.gamer.deriveFont(40f));
			g.setColor(Color.WHITE);
			g.drawString("BUILD MODE", 10, 44);
			
			
			g.setColor(new Color(0.2f, 0.2f, 0.2f, 0.7f));
			g.fillRect(Game.getWidth() - 100, Game.getHeight() - 100, 100, 100);
			
			Player p = Game.getWorld().getSelf();
			if(p != null){
				if(p.buildSelected != null && p.buildPreview != null){
					AffineTransform trans = g.getTransform();
					g.translate(Game.getWidth() - 50, Game.getHeight() - 50);
					p.buildPreview.renderScaled(g);
					g.setTransform(trans);
					
					String num = "" + p.inventory.get(p.buildSelected);
					
					g.setFont(Fonts.pixelmix.deriveFont(20f));
					int x = Game.getWidth() - g.getFontMetrics().stringWidth(num) - 8;
					
					GlyphVector gv = g.getFont().createGlyphVector(g.getFontRenderContext(), num);
					Shape shape = gv.getOutline();
					g.setStroke(new BasicStroke(4.0f));
					g.setColor(Color.BLACK);
					g.translate(x, Game.getHeight() - 10);
					g.draw(shape);
					
					g.setStroke(new BasicStroke(1.0f));
					g.setColor(Color.WHITE);
					g.drawString(num, 0, 0);
					
					g.setTransform(trans);
				}
			}
			
		}
		
	}

	public void tick(){
		
		//System.out.println(GameObject.SCALE);
		//System.out.println(Math.round((float)(GameObject.SCALE*100f))/100f);
		
		//System.out.println("aa");
		
		//System.out.println(GameObject.SCALE + " " + GameObject.DESIRED_SCALE);
		
		GameObject.DESIRED_SCALE = (Math.round((float)(GameObject.DESIRED_SCALE*100f))/100f);
		GameObject.SCALE += (GameObject.DESIRED_SCALE - GameObject.SCALE + GameObject.ZOOM_SCALE)/4f;
		//GameObject.SCALE = GameObject.DESIRED_SCALE;
		GameObject.SCALE = (Math.round((float)(GameObject.SCALE*10f))/10f);
		//System.out.println(GameObject.SCALE);
		if(GameObject.SCALE < 0.1) {
			//GameObject.SCALE = 1;
			//GameObject.DESIRED_SCALE = 1;
			GameObject.ZOOM_SCALE *= 0.95;
		}
			
		//System.out.println(GameObject.SCALE);
		
		if(Game.isServer()){
			xOffset = -5 * GameObject.SCALE + Game.getDisp().realWidth/2;
    		yOffset = -5 * GameObject.SCALE + Game.getDisp().realHeight/2;
		}else{
    		xOffset = -selfPlayer.base.getWorldCenter().x * GameObject.SCALE + Game.getDisp().realWidth/2;
    		yOffset = -selfPlayer.base.getWorldCenter().y * GameObject.SCALE + Game.getDisp().realHeight/2;
		}
		
//		xOffset = 0;
//		yOffset = 0;
		
		xOffset = (Math.round((float)(xOffset*100f))/100f);
		yOffset = (Math.round((float)(yOffset*100f))/100f);
		
		
		AffineTransform trans = new AffineTransform();
		
		trans.concatenate(Game.getWorld().getTransform());
		trans.scale(GameObject.SCALE, GameObject.SCALE);
		trans.translate(fieldXofs, fieldYofs);
		
		Point mPos = Game.mouseLoc();
		
		Point pt = new Point();
		try {
			AffineTransform inv = trans.createInverse();
			Point2D.Float f = new Point2D.Float(0, 0);
			inv.transform(mPos, f);
//			System.out.println(f);
		}catch (NoninvertibleTransformException e) {
			e.printStackTrace();
		}
	
		
//		if(Game.getTime() % 30 == 0){
//			
//			double dx = selfPlayer.getLocation().x - 1;
//			double dy = selfPlayer.getLocation().y - 0;
//			
//			System.out.println(dx + " " + dy);
//			
//			double angle = Math.atan2(dy, dx) + Math.toRadians(90);
//			
//			System.out.println(Math.toDegrees(angle));
//			
//			Bullet b = new Bullet("null", 1, 0, angle);
//			addBullet(b);
//		}
		
		//System.out.println("bb");
		
		List<Body> bodies = new ArrayList<Body>();
		bodies.addAll(world.getBodies());
		for(Body b : bodies){
			GameObject o = (GameObject) b;
			//System.out.println(o.getWorldCenter());
//			if(water != null){
//				if(o != water && o.getMass().getType() == MassType.NORMAL){
//					
//					double contains = water.containsFixture(o);
//					System.out.println(contains + " " + o.getMass().getMass());
//					if(contains > o.getMass().getMass()){
//						//System.out.println(o.getMass().getCenter().copy().subtract(o.getWorldCenter()).x);
//						//System.out.println((o.getMass().getCenter().x-o.getWorldCenter().x/GameObject.SCALE) + " " + o.getWorldCenter().x);
//						//System.out.println(contains + " " + o.getMass().getMass());
//						o.applyForce(new Vector2(0, (-world.getGravity().y * 1.5f) * o.getMass().getMass()));
//						
//						//System.out.println(o + " " + o.desiredRotation());
//						//System.out.println(o + " " + o.desiredRotation);
//						float desiredRot = o.desiredRotation;
//						
//						float rot = (float) Math.toDegrees(o.getTransform().getRotation());
//						//rot += 90;
//						//rot %= 360;
//						//rot += 180;
//						//rot = 180;
//						rot += desiredRot;
//						//System.out.println(rot - desiredRot);
//						
//						float correction = (float) (-rot / GameObject.SCALE);
//						
//						//System.out.println(o.getMass().getMass());
//						float range = (float) 2.4f;
//						
//						//System.out.println(rot + " " + correction);
//							if(correction > o.getTorque() + range){
//								correction = 0;
//							}else if(correction < o.getTorque() - range){
//								correction = 0;
//							}
//						o.applyTorque(correction * o.getMass().getMass());
//					}
//				}
//			}
			
//			if(Game.game.input.leftMouse && o.pullable){
//				//System.out.println(o.getMass().getMass());
//				Point frameloc = Game.game.frame.getLocation();
//				frameloc.x += Game.game.frame.getInsets().right;
//				frameloc.y += Game.game.frame.getInsets().top;
//				//System.out.println();
//				Vector2 mouse = new Vector2(MouseInfo.getPointerInfo().getLocation().getX() - frameloc.getX() - xOffset, MouseInfo.getPointerInfo().getLocation().getY() - frameloc.getY() - yOffset);
//				//System.out.println(mouse + " " + o.getWorldCenter());
//				o.applyForce(mouse.subtract(o.getWorldCenter().multiply(GameObject.SCALE)).multiply(0.1f).multiply(o.getMass().getMass()));
//				//o.applyForce(new Vector2(new Vector2(), new Vector2(o.getLocalCenter(), y)));
//			}
		}
		
//		if(Game.game.input.rightMouse && Game.game.time % 5 == 0){
//			Point frameloc = Game.game.frame.getLocation();
//			frameloc.x += Game.game.frame.getInsets().right;
//			frameloc.y += Game.game.frame.getInsets().top;
//			
//			GameObject go = new GameObject();
//			BodyFixture fix = new BodyFixture(new Circle(2 / GameObject.SCALE));
//			fix.setDensity(0.5f);
//			go.addFixture(fix);
//			go.translate((Game.game.input.rStart.x - frameloc.x) / GameObject.SCALE, (Game.game.input.rStart.y - frameloc.y) / GameObject.SCALE);
//			go.setMass(MassType.NORMAL);
//			
//			Vector2 mouse = new Vector2(MouseInfo.getPointerInfo().getLocation().getX() - frameloc.getX(), MouseInfo.getPointerInfo().getLocation().getY() - frameloc.getY());
//			go.applyForce(mouse.subtract(go.getWorldCenter().multiply(GameObject.SCALE)).multiply(4f).multiply(go.getMass().getMass()));
//			go.color = new Color(64, 64, (go.color.getBlue()));
//			world.addBody(go);
//			
//			Scheduler.delayedTask(new Runnable() {
//				@Override
//				public void run() {
//					// TODO Auto-generated method stub
//					toRemove.add(go);
//				}
//			}, 60 * 5);
//			//g.drawLine(Game.game.input.rStart.x - frameloc.x, Game.game.input.rStart.y - frameloc.y, MouseInfo.getPointerInfo().getLocation().x - frameloc.x, MouseInfo.getPointerInfo().getLocation().y - frameloc.y);
//		}
		
		for(Player p : players){
			if(p != null) p.tick();
		}
		
		List<GameObject> par = new ArrayList<GameObject>();
		par.addAll(particles);
		for(GameObject o : par){
			if(System.currentTimeMillis() >= o.destructionTime){
				if(world.removeBody(o)){
					particles.remove(o);
				}
			}
		}
		
		List<Switch> sca = new ArrayList<Switch>();
		sca.addAll(scales);
		for(Switch o : sca){
			if(o != null) o.tick();
		}
		
		List<GameObject> rem = new ArrayList<GameObject>();
		rem.addAll(toRemove);
		for(GameObject o : rem){
			world.removeBody(o);
			toRemove.remove(o);
		}
		
		try{
			world.update(1d/60d);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		//System.out.println("ff");
	}
	
	public GameObject createBoatObject(){
		GameObject r1 = new GameObject();
		BodyFixture bf1 = r1.addFixture(new Polygon(new Vector2(180 / GameObject.SCALE, 300 / GameObject.SCALE), new Vector2(100 / GameObject.SCALE, 200 / GameObject.SCALE), new Vector2(0 / GameObject.SCALE, 0 / GameObject.SCALE)));
		bf1.setDensity(0.5f);
		
//		Rectangle w1 = new Rectangle(44d / GameObject.SCALEd, 14d / GameObject.SCALEd);
//		w1.translate(0, -28 / GameObject.SCALEd);
//		BodyFixture bf2 = r1.addFixture(w1);
//		bf2.setDensity(0.1f);
		
//		Rectangle w2 = new Rectangle(44d / GameObject.SCALEd, 12d / GameObject.SCALEd);
//		w2.translate(0, 20 / GameObject.SCALEd);
//		BodyFixture bf3 = r1.addFixture(w2);
//		bf3.setDensity(0.1f);
		
		r1.setMass(MassType.NORMAL);
		r1.desiredRotation = (float) GameObject.SCALE;
		
		return r1;
	}
	
	public Player getSelf(){
		return selfPlayer;
	}

	public Player getPlayer(String name) {
		for(Player p : players){
//			System.out.println(p.name);
			if(p != null && p.name != null) if(p.name.equals(name)) return p;
		}
		return null;
	}

	public List<Player> getPlayers() {
		return players;
	}

	public void removePlayer(Player player) {
		players.remove(player);
		if(player.base != null) world.removeBody(player.base);
	}
	
	public void addParticle(GameObject obj){
		particles.add(obj);
		world.addBody(obj);
	}
	
	public void addPowerCube(PowerCube obj){
		cubes.add(obj);
		world.addBody(obj.base);
	}

	public Component getComponent(GameObject go) {
		for(Player p : players){
			if(p.ship == null) continue;
			Component c = p.ship.getComponent(go);
			if(c != null) return c;
		}
		return null;
	}

	public void removeComponent(Component comp) {
		for(Player p : players){
			Component c = p.ship.getComponent(comp.lastBody);
			if(c != null) {
				p.destroyComponent(c);
			}
		}
	}

	public Player getPlayer(Component comp) {
		for(Player p : players){
			Component c = p.ship.getComponent(comp.lastBody);
			if(c != null) return p;
		}
		return null;
	}

	public boolean isPowerCube(GameObject o) {
		for(PowerCube b : cubes){
			if(b.base == o) return true;
		}
		return false;
	}
	
	public List<PowerCube> getCubes(){
		List<PowerCube> pc = new ArrayList<PowerCube>();
		pc.addAll(cubes);
		return pc;
	}

	public void removeCube(PowerCube c) {
		cubes.remove(c);
		world.removeBody(c.base);
	}
	
	public void addScale(Switch scale){
		scales.add(scale);
		scalePlatforms.add(scale.getRedPlatform());
		scalePlatforms.add(scale.getBluePlatform());
		world.addBody(scale.getBluePlatform().base);
		world.addBody(scale.getRedPlatform().base);
	}
	
	public boolean isCubeOnScale(PowerCube cube) {
		for(ScalePlatform sp : scalePlatforms) {
			if(sp.base.contains(cube.base.getWorldCenter())) {
				return true;
			}
		}
		return false;
	}
	
}
