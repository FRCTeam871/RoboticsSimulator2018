package me.pieking.game.net.packet;

public abstract class Packet {
	
	public abstract String format();
	public abstract void doAction();
	
}
