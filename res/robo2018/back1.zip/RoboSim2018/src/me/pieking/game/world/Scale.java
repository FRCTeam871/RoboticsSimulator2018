package me.pieking.game.world;

public class Scale extends Switch {

	public Scale(double x, double y) {
		super(x, y);
		red = new ScalePlatform(x, y - 4.75);
		blue = new ScalePlatform(x, y + 4.75);
	}

}
