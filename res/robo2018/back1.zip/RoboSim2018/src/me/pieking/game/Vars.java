package me.pieking.game;

public class Vars {

	public static boolean showCollision = false;
	
}
