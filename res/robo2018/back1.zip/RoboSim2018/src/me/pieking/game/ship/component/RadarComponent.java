package me.pieking.game.ship.component;

import java.awt.Color;
import java.awt.Point;

import org.dyn4j.dynamics.BodyFixture;
import org.dyn4j.geometry.Mass;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Polygon;
import org.dyn4j.geometry.Vector2;

import me.pieking.game.gfx.AnimatedImage;
import me.pieking.game.gfx.Sprite;
import me.pieking.game.gfx.Spritesheet;
import me.pieking.game.scripting.LuaScript;
import me.pieking.game.world.GameObject;
import me.pieking.game.world.Player;
import me.pieking.game.world.PlayerFilter;

public class RadarComponent extends Component {

	public static AnimatedImage sprOn;
	static {
		Point[] onPts = new Point[8];
		for(int i = 0; i < onPts.length; i++){
			onPts[i] = new Point(i, 2);
		}
		sprOn = Spritesheet.tiles.animatedTile(onPts);
		sprOn.speed = 10f;
	}
	
	public LuaScript script;
	
	public RadarComponent(int x, int y, int rot) {
		super(x, y, 1, 1, rot, 100);
		sprite = sprOn;
	}
	
	@Override
	public GameObject createBody(Player player){
		
		GameObject base = new GameObject();
		base.setAutoSleepingEnabled(false);
		base.color = Color.GRAY;
		org.dyn4j.geometry.Rectangle r = new org.dyn4j.geometry.Rectangle(bounds.width * unitSize, bounds.width * unitSize);
		BodyFixture bf = new BodyFixture(r);
		bf.setFilter(new PlayerFilter(player));
		base.addFixture(bf);
		base.setMass(new Mass(base.getMass().getCenter(), 0, 0));
		base.setMass(MassType.NORMAL);
		
		base.setAngularDamping(0);
		base.setLinearDamping(0);
		
		return base;
	}

	@Override
	public String getDisplayName() {
		return "Radar";
	}
	
}
