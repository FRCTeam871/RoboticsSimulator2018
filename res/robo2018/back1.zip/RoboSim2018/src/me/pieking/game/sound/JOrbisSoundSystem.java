package me.pieking.game.sound;

public class JOrbisSoundSystem extends SoundSystem{

	@Override
	public void init() {
		
	}

	@Override
	public SoundClip playSoundFinal(String name, float volume, boolean loop, boolean priority) {
		return null;
	}

	@Override
	public SoundClip loadSound(String name) {
		return null;
	}

	@Override
	public boolean canLoadSounds() {
		return false;
	}

	@Override
	public void periodic() {
		
	}

	@Override
	public void shutdown() {
		// TODO Auto-generated method stub
		
	}

}
