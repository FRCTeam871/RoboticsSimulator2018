package me.pieking.game.ship.component;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;

import org.dyn4j.dynamics.BodyFixture;
import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.Mass;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Polygon;
import org.dyn4j.geometry.Vector2;

import me.pieking.game.Game;
import me.pieking.game.gfx.AnimatedImage;
import me.pieking.game.gfx.Images;
import me.pieking.game.gfx.Sprite;
import me.pieking.game.gfx.Spritesheet;
import me.pieking.game.ship.Ship;
import me.pieking.game.world.GameObject;
import me.pieking.game.world.Player;
import me.pieking.game.world.PlayerFilter;

public class ShieldsComponent extends ActivatableComponent {

	public static Sprite spr_shield = Images.getSprite("shieldPx.png");
	public static Sprite spr_shield_depleted = Images.getSprite("shieldBadPx.png");
	
	public static Sprite sprOff = Spritesheet.tiles.subTile(0, 9);
	public static AnimatedImage sprOn;
	static {
		Point[] onPts = new Point[4];
		for(int i = 0; i < onPts.length; i++){
			onPts[i] = new Point(i + 1, 9);
		}
		sprOn = Spritesheet.tiles.animatedTile(onPts);
		sprOn.speed = 20f;
	}
	
	public Shape shieldArea;
	public int lastHit = 0;
	
	public int shieldCharge = 100;
	
	public ShieldsComponent(int x, int y, int rot) {
		super(x, y, 1, 1, rot, 100);
		sprite = sprOff;
		toggleMode = true;
	}
	
	@Override
	public GameObject createBody(Player player){
		
		GameObject base = new GameObject();
		base.setAutoSleepingEnabled(false);
		base.color = Color.GRAY;
		Polygon p = new Polygon(new Vector2(unitSize * (3./8.), 0), new Vector2(unitSize*(5./8.), 0), new Vector2(unitSize, unitSize/2), new Vector2(unitSize, unitSize), new Vector2(0, unitSize), new Vector2(0, unitSize/2));
		p.translate(-unitSize/2, -unitSize/2);
		BodyFixture bf = new BodyFixture(p);
		bf.setFilter(new PlayerFilter(player));
		base.addFixture(bf);
		base.setMass(new Mass(base.getMass().getCenter(), 0, 0));
		base.setMass(MassType.NORMAL);
		
		base.setAngularDamping(0);
		base.setLinearDamping(0);
		
		return base;
	}
	
	@Override
	public void tick(Player pl) {
		super.tick(pl);
		
		Ship s = Game.getWorld().getPlayer(this).ship;
		float xMod = 0;
		
		boolean adjacent[] = new boolean[4];
		
		adjacent[0] = s.getComponent(new Point(bounds.x + 1, bounds.y)) != null;
		adjacent[1] = s.getComponent(new Point(bounds.x, bounds.y + 1)) != null;
		adjacent[2] = s.getComponent(new Point(bounds.x - 1, bounds.y)) != null;
		adjacent[3] = s.getComponent(new Point(bounds.x, bounds.y - 1)) != null;
		
		boolean hasRight = adjacent[(0 + (rot/90))%4];
		boolean hasDown  = adjacent[(1 + (rot/90))%4];
		boolean hasLeft  = adjacent[(2 + (rot/90))%4];
		boolean hasUp    = adjacent[(3 + (rot/90))%4];
		
		shieldArea = getProtectedArc();
		
		if(shieldCharge < 100 && Game.getTime() % 5 == 0) shieldCharge++;
		
//		System.out.println(shieldCharge);
		
//		System.out.println(hasRight + " " + hasDown + " " + hasLeft + " " + hasUp);
		
//		if(hasRight && !hasLeft && !hasDown){
//			sprite = attachedRight;
//		}
//		
//		if(hasLeft && !hasRight && !hasDown){
//			sprite = attachedLeft;
//		}
//		
//		if(hasDown && !hasRight && !hasLeft){
//			sprite = attachedDown;
//		}
//		
//		if(sprite == attachedDown && !hasDown){
//			if(hasRight){
//				sprite = attachedRight;
//			}else if(hasLeft){
//				sprite = attachedLeft;
//			}
//		}else if(sprite == attachedRight && !hasRight){
//			if(hasDown){
//				sprite = attachedDown;
//			}else if(hasLeft){
//				sprite = attachedLeft;
//			}
//		}else if(sprite == attachedLeft && !hasLeft){
//			if(hasDown){
//				sprite = attachedDown;
//			}else if(hasRight){
//				sprite = attachedRight;
//			}
//		}
		
		
		if(pl == Game.getWorld().getSelf()){
    		if(activated){
//    			System.out.println("shields up");
//    			int fr = (int) ((Game.getTime()/20f) % (4));
//    			
//    			System.out.println(fr);
    		}
		}
		
	}
	
	@Override
	public void activate() {
		super.activate();

		sprite = sprOn;
	}
	
	@Override
	public void deactivate() {
		super.deactivate();
		
		sprite = sprOff;
	}
	
	@Override
	public String getDisplayName() {
		return "Shield Generator";
	}
	
	@Override
	public void render(Graphics2D g) {
		super.render(g);
	}
	
	public Shape getProtectedArc(){
		
		double xSize = 10 * unitSize;
		double ySize = 6 * unitSize;
		
	    double x = -xSize/2;
	    double y = -ySize/2;
		
		x += lastBody.getWorldCenter().x;
		y += lastBody.getWorldCenter().y;
		
		Arc2D arc = new Arc2D.Double(x, y, xSize, ySize, 90 - 45, 90, Arc2D.PIE);
		
		AffineTransform rot = AffineTransform.getRotateInstance(lastBody.getTransform().getRotation(), x + xSize/2, y + ySize/2);
		
		return rot.createTransformedShape(arc);
	}
	
	public float getShieldOpacity(){
		float pulse = (float)((Math.sin(Game.getTime() / 20f) + 1) / 2f) / 4f + 0.5f; // 0.25 to 0.75
		
		if(Game.getTime() - lastHit < 60){
			pulse += (1f - ((Game.getTime() - lastHit) / 60f)) / 4f;
		}
		
		if(pulse < 0f) pulse = 0f;
		if(pulse > 1f) pulse = 1f;
		
		return pulse;
	}
	
	public boolean shieldActive(){
		return shieldCharge > 0;
	}
	
	public float shieldHealth(){
		if(shieldCharge > 0){
			return shieldCharge / 100f;
		}else{
			return 0f;
		}
	}
	
	public void hit(){
		
		lastHit = Game.getTime();
		
		int old = shieldCharge;
		
		if(shieldCharge > 0) shieldCharge -= 10;

		if(shieldCharge <= 0 && old > 0){ // if the shields just got taken down
			shieldCharge = -100;
		}
	
	}

}
