package me.pieking.game.menu;

public abstract interface ChoiceListener {

	public abstract void choose(int index);
	
}
